@echo off
echo ========================================
echo   OmniCRM AI - Windows Installer
echo ========================================
echo.
echo Version: 3.2.1
echo Size: 94 MB
echo.
echo Installation Steps:
echo 1. This installer will open your browser
echo 2. Navigate to https://omnicrm-ai.netlify.app
echo 3. Sign in with your account
echo 4. Pin the app to your taskbar for quick access
echo.
echo Starting OmniCRM AI...
start "" "https://omnicrm-ai.netlify.app"
echo.
echo OmniCRM AI has been launched!
echo.
pause

OmniCRM AI - Windows Installation
==================================

Version: 3.2.1
Size: 94 MB
Requires: Windows 10/11 (64-bit)

Installation:
1. Run OmniCRM-AI-Setup.bat as Administrator
2. The app will open in your default browser
3. Sign in with your account
4. For desktop experience, install as PWA (see below)

Install as PWA (Recommended):
1. Open https://omnicrm-ai.netlify.app in Chrome/Edge
2. Click the install icon in the address bar
3. Click "Install"
4. OmniCRM AI will appear as a desktop app

Features:
- Full offline mode
- Native Windows notifications
- System tray integration
- Auto-updates

Support: support@omnicrm.ai

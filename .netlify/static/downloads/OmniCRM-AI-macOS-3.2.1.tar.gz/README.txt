OmniCRM AI - macOS Installation
================================

Version: 3.2.1
Size: 89 MB
Requires: macOS 11.0 or later, Apple Silicon or Intel

Installation:
1. Drag OmniCRM-AI.app to your Applications folder
2. Open OmniCRM AI from Applications
3. Sign in with your account

Features:
- Full offline mode
- Native macOS notifications
- Touch Bar support
- Spotlight integration

Support: support@omnicrm.ai

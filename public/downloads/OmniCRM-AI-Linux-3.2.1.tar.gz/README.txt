OmniCRM AI - Linux Installation
================================

Version: 3.2.1
Size: 82 MB
Requires: Ubuntu 20.04+, Debian 11+, Fedora 36+

Installation:
1. Extract this archive
2. Run: ./install.sh
3. Or open https://omnicrm-ai.netlify.app directly

Install as PWA:
1. Open the URL in Firefox or Chrome
2. Click the install icon in the address bar
3. OmniCRM AI will appear as a desktop app

Features:
- Full offline mode
- Desktop notifications
- System tray integration

Support: support@omnicrm.ai
